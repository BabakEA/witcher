ScotiBank Recommnder_system Project


Pleae rename Recommender.txt to Recommender.py
app.txt to app.py


to run the recommnder system, Please run the jupyter_notebook (Recommender_system_OCT_26.ipynb) file.

To test the Rest application (Web-based page), Please run the app.py file using python:

python app.py

Please feel free to call me at +1(647)-326-6199 if you had any difficulties
Thank you 
Babak.EA
 