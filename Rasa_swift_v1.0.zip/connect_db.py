#!/usr/bin/python

import sqlite3
import pandas

conn = sqlite3.connect('swift_db.db')
# data = pandas.read_csv("SWift_db.csv")
# data.to_sql(name='swift_db', index=False, con=conn)
cur = conn.cursor()
# cur.execute('SELECT DISTINCT Bank FROM  swift_db where Country like "%argentina%" limit 5 ')
cur.execute("SELECT DISTINCT Country FROM swift_db;")

rows = cur.fetchall()
data = list()
for row in rows:
    # data.append(row[0])
    print(row[0])

# data = "\n    - ".join(data)
# with open("banks.txt","w+") as file:
#     file.write(data)
# # print(data)
