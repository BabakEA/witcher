import sqlite3
from typing import Dict, Text, Any, List, Union
from rasa_sdk import Tracker
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.forms import FormValidationAction

#   - username
#   - country_name
#   - bank_name
#   - swift_code
#   - confirm_bank
#   - transaction_money
#   - confirm_transaction
 
conn = sqlite3.connect('swift_db.db')
cur = conn.cursor()


class ValidateTransferMoneyForm(FormValidationAction):
    """transfer money form validation action."""

    def name(self) -> Text:
        return "validate_transfer_money_form"
    
    
    def validate_username(
        self,
        value: Text,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> Dict[Text, Any]:
        """Validate username value."""

        # dispatcher.utter_message(response="utter_wrong_cuisine")
        return {"username": value}

    def validate_country_name(
        self,
        value: Text,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> Dict[Text, Any]:
        """Validate country_name value."""
        print("bank_name", tracker.get_slot("bank_name"))
        
        if not tracker.get_slot("bank_name"):
            cur.execute('SELECT DISTINCT Bank FROM  swift_db where Country like "%argentina%" limit 5')
            rows = cur.fetchall()
            buttons = list()
            for row in rows:
                buttons.append({"title": row[0], "payload": row[0]})

            dispatcher.utter_message(text="May I know the name of the institute?",buttons=buttons)

        return {"country_name": value}

    def validate_bank_name(
        self,
        value: Text,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> Dict[Text, Any]:
        """Validate bank_name value."""
        # print('xxxxxxxxxxxxxxxxxxxxxxxxxxxx')
        # print("bank_name", value)
        # cur.execute('SELECT DISTINCT Bank FROM  swift_db where Country like "%argentina%" limit 5')
        # rows = cur.fetchall()
        # buttons = list()
        # for row in rows:
        #     buttons.append({"title": row[0], "payload": row[0]})
        return {"bank_name": value, "confirm_bank": None}

    def validate_confirm_bank(
        self,
        value: Text,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> Dict[Text, Any]:
        """Validate confirm_bank value."""
        print('xxxxxxxxxxxxxxxxxxxxxxxxxxxx')
        print("confirm_bank", value)
        return {"confirm_bank": value, "confirm_transaction":None}

    def validate_confirm_transaction(
        self,
        value: Text,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> Dict[Text, Any]:
        """Validate confirm_transaction value."""
        print('xxxxxxxxxxxxxxxxxxxxxxxxxxxx')
        print("confirm_transaction", value)
        return {"confirm_transaction": value}  


    def validate_transaction_money(
        self,
        value: Text,
        dispatcher: CollectingDispatcher,
        tracker: Tracker,
        domain: Dict[Text, Any],
    ) -> Dict[Text, Any]:
        """Validate transaction_money value."""

        # dispatcher.utter_message(response="utter_wrong_cuisine")
        return {"transaction_money": value}



# Fetch the data and store in the format used by buttons.
# buttons = [{"title": "Rohan Shah", "payload": "/intent_name"}, {"title": "Rohan Pandya", "payload": "/intent_name"}]
# dispatcher.utter_button_message("There are 2 people with the name Rohan:", buttons)